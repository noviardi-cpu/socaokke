import React, { useState, useRef, useEffect } from 'react';
import { AgeGroup, ChatMessage, TeacherPreferences } from './types.ts';
import { THEMES, THEME_EXPLANATIONS, MODEL_OKKE_INFO, THEORY_IPS, STPPA_INFO, STPPA_AGE_DETAILS } from './constants.ts';
import { generateSocaResponse } from './services/geminiService.ts';
import { 
  Sparkles, 
  MapPin, 
  Users, 
  BookOpen, 
  Layers, 
  Info, 
  ChevronRight, 
  Printer, 
  Copy, 
  Send,
  User,
  Bot,
  RefreshCw,
  X,
  MessageCircle,
  FileText
} from 'lucide-react';

const AGE_GROUP_CARDS = [
  { group: AgeGroup.TPA_0_1, icon: '🍼', color: 'bg-rose-100', text: 'text-rose-600', label: 'TPA 0-1 Thn' },
  { group: AgeGroup.TPA_1_2, icon: '🧸', color: 'bg-orange-100', text: 'text-orange-600', label: 'TPA 1-2 Thn' },
  { group: AgeGroup.KOBER_2_3, icon: '🧩', color: 'bg-amber-100', text: 'text-amber-600', label: 'Kober 2-3 Thn' },
  { group: AgeGroup.KOBER_3_4, icon: '🎨', color: 'bg-emerald-100', text: 'text-emerald-600', label: 'Kober 3-4 Thn' },
  { group: AgeGroup.TK_A, icon: '🎒', color: 'bg-sky-100', text: 'text-sky-600', label: 'TK A 4-5 Thn' },
  { group: AgeGroup.TK_B, icon: '🏫', color: 'bg-indigo-100', text: 'text-indigo-600', label: 'TK B 5-6 Thn' },
];

const App: React.FC = () => {
  // Persistence logic
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('soca_messages');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [showThemeModal, setShowThemeModal] = useState(false);
  const [showOKKEModal, setShowOKKEModal] = useState(false);
  const [showIPSModal, setShowIPSModal] = useState(false);
  const [showSTPPADetailModal, setShowSTPPADetailModal] = useState<AgeGroup | null>(null);
  
  const [prefs, setPrefs] = useState<TeacherPreferences>(() => {
    const saved = localStorage.getItem('soca_prefs');
    return saved ? JSON.parse(saved) : {
      desa: '',
      kecamatan: '',
      kabupaten: '',
      provinsi: '',
      ageGroup: AgeGroup.TK_A,
      theme: THEMES[0]
    };
  });

  const scrollRef = useRef<HTMLDivElement>(null);
  const chatInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem('soca_messages', JSON.stringify(messages));
    localStorage.setItem('soca_prefs', JSON.stringify(prefs));
  }, [messages, prefs]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSubmit = async (e?: React.FormEvent, customMessage?: string) => {
    e?.preventDefault();
    
    const locationInfo = (prefs.desa && prefs.kecamatan && prefs.kabupaten && prefs.provinsi) 
      ? `di Desa/Kelurahan ${prefs.desa}, Kecamatan ${prefs.kecamatan}, ${prefs.kabupaten}, Provinsi ${prefs.provinsi}`
      : '(lokasi belum lengkap)';

    const content = customMessage || `Halo SocaPAUD, saya guru ${locationInfo} mengajar jenjang ${prefs.ageGroup}. Saya ingin merancang kegiatan dengan tema "${prefs.theme}". Tolong buatkan rencana kegiatan menggunakan Model OKKE dengan fokus pada integrasi Studi Sosial.`;
    
    const newUserMessage: ChatMessage = {
      role: 'user',
      content,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, newUserMessage]);
    setIsLoading(true);

    try {
      const response = await generateSocaResponse(
        content, 
        messages.slice(-6).map(m => ({ role: m.role, content: m.content }))
      );

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: response,
        timestamp: Date.now()
      }]);
    } catch (err) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "Mohon maaf, terjadi gangguan koneksi. Mari kita coba lagi orkestrasinya.",
        timestamp: Date.now()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearHistory = () => {
    if (confirm("Hapus semua riwayat percakapan?")) {
      setMessages([]);
      localStorage.removeItem('soca_messages');
    }
  };

  const handleAgeGroupSelect = (group: AgeGroup) => {
    setPrefs(prev => ({ ...prev, ageGroup: group }));
    setShowSTPPADetailModal(group);
  };

  const confirmAgeSelection = () => {
    const group = showSTPPADetailModal;
    if (!group) return;
    setShowSTPPADetailModal(null);
    handleSubmit();
  };

  const handlePrint = (content: string) => {
    const printArea = document.getElementById('print-area');
    if (!printArea) return;
    
    const formattedHtml = content
      .replace(/^# (.*$)/gm, '<h1 class="print-title">$1</h1>')
      .replace(/^## (.*$)/gm, '<h2 class="print-title">$1</h2>')
      .replace(/^### (.*$)/gm, '<h3 class="print-title">$1</h3>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/^\s*[\*\-]\s+(.*$)/gm, '<li>$1</li>')
      .replace(/(<li>.*<\/li>)/gms, '<ul>$1</ul>')
      .replace(/\n\n/g, '</p><p>')
      .replace(/\n/g, '<br/>');

    printArea.innerHTML = `
      <div class="print-header">
        <h1 style="font-size: 24pt; margin: 0; font-family: 'Fraunces', serif;">Rencana Pembelajaran Model OKKE</h1>
        <p style="font-size: 11pt; margin: 5px 0;">SocaPAUD - Social & Culture Assistant for Early Childhood Education</p>
      </div>
      <div class="print-section" style="background: #f8f8f8; padding: 15px; border: 1px solid #ddd;">
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="font-weight: bold; width: 120px;">Satuan PAUD:</td>
            <td>${prefs.desa || '-'}, ${prefs.kecamatan || '-'}, ${prefs.kabupaten || '-'}</td>
          </tr>
          <tr>
            <td style="font-weight: bold;">Kelompok Usia:</td>
            <td>${prefs.ageGroup}</td>
          </tr>
          <tr>
            <td style="font-weight: bold;">Tema:</td>
            <td>${prefs.theme}</td>
          </tr>
        </table>
      </div>
      <div class="prose-print">
        <p>${formattedHtml}</p>
      </div>
      <div class="print-footer">
        <p>Dokumen ini dirancang melalui sistem SocaPAUD (Model OKKE)</p>
        <p>Pengembang: Huriah Rachmah, PG PAUD, Unisba &bull; Dicetak: ${new Date().toLocaleDateString('id-ID', { dateStyle: 'full' })}</p>
      </div>
    `;
    setTimeout(() => {
      window.print();
      printArea.innerHTML = '';
    }, 300);
  };

  const formatMarkdownToJSX = (text: string) => {
    return text.split('\n').map((line, i) => {
      if (line.startsWith('# ')) return <h1 key={i} className="text-2xl font-black text-slate-800 mt-6 mb-4 font-serif">{line.replace('# ', '')}</h1>;
      if (line.startsWith('## ')) return <h2 key={i} className="text-xl font-black text-slate-800 mt-5 mb-3">{line.replace('## ', '')}</h2>;
      if (line.startsWith('### ')) return <h3 key={i} className="text-lg font-bold text-slate-700 mt-4 mb-2">{line.replace('### ', '')}</h3>;
      if (line.startsWith('**') && line.endsWith('**')) return <p key={i} className="font-bold text-indigo-700 mt-4 mb-1">{line.replace(/\*\*/g, '')}</p>;
      if (line.startsWith('- ') || line.startsWith('* ')) return <li key={i} className="ml-5 list-disc mb-1 text-slate-600 leading-relaxed">{line.substring(2)}</li>;
      if (!line.trim()) return <div key={i} className="h-2" />;
      return <p key={i} className="text-slate-600 leading-relaxed mb-3">{line}</p>;
    });
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-100">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 joyful-gradient rounded-2xl flex items-center justify-center shadow-sm border border-white">
              <Sparkles className="text-indigo-600 w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tighter text-slate-800 leading-none">SocaPAUD</h1>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">OKKE Model Assistant</span>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-6">
            <button onClick={() => setShowOKKEModal(true)} className="text-[11px] font-black text-slate-500 uppercase tracking-widest hover:text-indigo-600 transition-colors flex items-center gap-2">
              <Layers className="w-3 h-3" /> Model OKKE
            </button>
            <button onClick={() => setShowIPSModal(true)} className="text-[11px] font-black text-slate-500 uppercase tracking-widest hover:text-indigo-600 transition-colors flex items-center gap-2">
              <BookOpen className="w-3 h-3" /> Landasan IPS
            </button>
            <div className="h-6 w-[1px] bg-slate-100" />
            <div className="text-right">
              <p className="text-[10px] font-black text-slate-800 leading-none">Huriah Rachmah</p>
              <p className="text-[9px] font-bold text-slate-400">PG PAUD, Unisba</p>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Control Panel */}
        <aside className="lg:col-span-4 space-y-6">
          {/* Profile Card */}
          <section className="bg-white rounded-[2rem] p-6 shadow-xl shadow-slate-200/50 border border-slate-100">
            <h2 className="text-sm font-black text-slate-800 mb-6 flex items-center gap-2 uppercase tracking-widest">
              <User className="w-4 h-4 text-indigo-500" /> Profil Pengajar
            </h2>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1 flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> Lokasi Satuan
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input 
                    placeholder="Desa/Kel" 
                    className="col-span-2 px-4 py-3 bg-slate-50 rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-100 outline-none transition-all"
                    value={prefs.desa}
                    onChange={e => setPrefs({...prefs, desa: e.target.value})}
                  />
                  <input 
                    placeholder="Kecamatan" 
                    className="px-4 py-3 bg-slate-50 rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-100 outline-none transition-all"
                    value={prefs.kecamatan}
                    onChange={e => setPrefs({...prefs, kecamatan: e.target.value})}
                  />
                  <input 
                    placeholder="Kab/Kota" 
                    className="px-4 py-3 bg-slate-50 rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-100 outline-none transition-all"
                    value={prefs.kabupaten}
                    onChange={e => setPrefs({...prefs, kabupaten: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1 flex items-center gap-1">
                  <Users className="w-3 h-3" /> Kelompok Usia
                </label>
                <select 
                  className="w-full px-4 py-3 bg-slate-50 rounded-xl text-xs font-bold outline-none cursor-pointer hover:bg-slate-100 transition-colors appearance-none"
                  value={prefs.ageGroup}
                  onChange={e => setPrefs({...prefs, ageGroup: e.target.value as AgeGroup})}
                >
                  {Object.values(AgeGroup).map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1 flex items-center gap-1">
                  <FileText className="w-3 h-3" /> Tema Pembelajaran
                </label>
                <div className="relative">
                  <select 
                    className="w-full px-4 py-3 bg-slate-50 rounded-xl text-xs font-bold outline-none cursor-pointer pr-10 hover:bg-slate-100 transition-colors appearance-none"
                    value={prefs.theme}
                    onChange={e => setPrefs({...prefs, theme: e.target.value})}
                  >
                    {THEMES.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                  <button 
                    onClick={() => setShowThemeModal(true)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-indigo-500 hover:scale-110 transition-transform"
                  >
                    <Info className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <button 
                onClick={() => handleSubmit()}
                disabled={isLoading}
                className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-sm shadow-lg shadow-indigo-100 transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50 mt-4"
              >
                {isLoading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <><Sparkles className="w-5 h-5" /> Orkestrasi AI</>}
              </button>
            </div>
          </section>

          {/* Theory Links */}
          <div className="grid grid-cols-1 gap-3">
             <button onClick={() => setShowOKKEModal(true)} className="flex items-center justify-between p-5 bg-white border border-slate-100 rounded-2xl hover:border-indigo-200 transition-all group">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center font-black">O</div>
                  <div className="text-left">
                    <p className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Model OKKE</p>
                    <p className="text-[9px] font-bold text-slate-400 line-clamp-1">Orkestrasi, Kurikulum, Kearifan, Etnopedagogi</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-indigo-400" />
             </button>
             <button onClick={() => setShowIPSModal(true)} className="flex items-center justify-between p-5 bg-white border border-slate-100 rounded-2xl hover:border-emerald-200 transition-all group">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center text-lg">📚</div>
                  <div className="text-left">
                    <p className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Teori IPS</p>
                    <p className="text-[9px] font-bold text-slate-400 line-clamp-1">Organisasi Psikologis ala Prof. Somantri</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-emerald-400" />
             </button>
          </div>
        </aside>

        {/* Right Chat/Display Panel */}
        <div className="lg:col-span-8 flex flex-col bg-white rounded-[2.5rem] shadow-2xl shadow-slate-200/60 border border-slate-100 overflow-hidden h-[600px] lg:h-[calc(100vh-160px)] relative">
          
          {/* Messages Area */}
          <div 
            ref={scrollRef}
            className="flex-1 overflow-y-auto p-6 md:p-10 space-y-8 custom-scrollbar bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-opacity-5"
          >
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center max-w-lg mx-auto space-y-8">
                <div className="w-24 h-24 joyful-gradient rounded-[2.5rem] flex items-center justify-center shadow-xl animate-bounce">
                  <Bot className="w-12 h-12 text-indigo-600" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-3xl font-black text-slate-800 tracking-tighter font-serif">Selamat Datang di SocaPAUD</h3>
                  <p className="text-slate-500 font-bold text-sm leading-relaxed">
                    Saya siap membantu Anda merancang kegiatan belajar yang menyenangkan dengan Model OKKE. Pilih kelompok usia atau tanyakan apa saja.
                  </p>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 w-full">
                  {AGE_GROUP_CARDS.map(card => (
                    <button 
                      key={card.label}
                      onClick={() => handleAgeGroupSelect(card.group)}
                      className="p-4 bg-white border border-slate-100 rounded-2xl hover:shadow-lg transition-all flex flex-col items-center gap-2 group hover:border-indigo-100"
                    >
                      <span className="text-2xl group-hover:scale-125 transition-transform">{card.icon}</span>
                      <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">{card.label}</span>
                    </button>
                  ))}
                </div>

                <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100 flex items-start gap-4 text-left">
                  <div className="w-8 h-8 bg-amber-200 rounded-lg flex items-center justify-center flex-shrink-0">🇮🇩</div>
                  <div>
                    <p className="text-[10px] font-black text-amber-800 uppercase tracking-widest mb-1">Update Kurikulum 2025</p>
                    <p className="text-[11px] font-bold text-amber-700">Terintegrasi dengan Permendikdasmen No. 13 Tahun 2025: Deep Learning & Joyful Learning.</p>
                  </div>
                </div>
              </div>
            ) : (
              messages.map((msg, idx) => (
                <div 
                  key={idx} 
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}
                >
                  <div className={`max-w-[90%] md:max-w-[85%] rounded-[2rem] p-6 md:p-8 shadow-sm ${
                    msg.role === 'user' 
                    ? 'bg-slate-900 text-white rounded-tr-none' 
                    : 'bg-slate-50 text-slate-800 rounded-tl-none border border-slate-100'
                  }`}>
                    <div className="flex items-center gap-2 mb-4">
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs ${msg.role === 'user' ? 'bg-slate-700' : 'bg-indigo-600 text-white'}`}>
                        {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                      </div>
                      <span className={`text-[10px] font-black uppercase tracking-widest ${msg.role === 'user' ? 'text-slate-400' : 'text-indigo-500'}`}>
                        {msg.role === 'user' ? 'Guru PAUD' : 'SocaPAUD Assistant'}
                      </span>
                    </div>
                    <div className="text-sm md:text-base">
                      {msg.role === 'user' ? <p className="font-bold leading-relaxed">{msg.content}</p> : formatMarkdownToJSX(msg.content)}
                    </div>

                    {msg.role === 'assistant' && (
                      <div className="mt-6 pt-4 border-t border-slate-200 flex items-center gap-2">
                        <button 
                          onClick={() => {
                            navigator.clipboard.writeText(msg.content);
                            alert("Berhasil disalin!");
                          }}
                          className="flex items-center gap-2 px-3 py-1.5 bg-white hover:bg-slate-100 rounded-lg text-[9px] font-black text-slate-500 uppercase tracking-widest transition-all border border-slate-200"
                        >
                          <Copy className="w-3 h-3" /> Salin
                        </button>
                        <button 
                          onClick={() => handlePrint(msg.content)}
                          className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 rounded-lg text-[9px] font-black text-indigo-600 uppercase tracking-widest transition-all border border-indigo-100"
                        >
                          <Printer className="w-3 h-3" /> Cetak
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white rounded-[2rem] p-6 rounded-tl-none border border-slate-100 shadow-sm flex items-center gap-4">
                   <div className="flex gap-1.5">
                     <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></div>
                     <div className="w-2 h-2 bg-indigo-300 rounded-full animate-bounce delay-150"></div>
                     <div className="w-2 h-2 bg-indigo-200 rounded-full animate-bounce delay-300"></div>
                   </div>
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">AI sedang Mengorkestrasi Kurikulum...</span>
                </div>
              </div>
            )}
          </div>

          {/* Chat Input Bar */}
          <div className="p-6 bg-white border-t border-slate-100">
            <div className="max-w-4xl mx-auto flex flex-col gap-3">
              <div className="flex items-center justify-between px-2">
                <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Ketik ide atau pertanyaan Anda</span>
                {messages.length > 0 && (
                  <button onClick={handleClearHistory} className="text-[9px] font-black text-rose-400 hover:text-rose-600 uppercase tracking-widest flex items-center gap-1 transition-colors">
                    Hapus Percakapan
                  </button>
                )}
              </div>
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  const val = chatInputRef.current?.value;
                  if (val?.trim()) {
                    handleSubmit(undefined, val);
                    chatInputRef.current!.value = '';
                  }
                }}
                className="flex items-center gap-3 bg-slate-50 p-2 rounded-2xl border border-slate-100 focus-within:ring-4 focus-within:ring-indigo-100 focus-within:bg-white transition-all shadow-inner"
              >
                <input 
                  ref={chatInputRef}
                  placeholder="Tanyakan ide kegiatan spesifik atau landasan teori..."
                  className="flex-1 px-4 py-3 bg-transparent outline-none text-sm font-bold text-slate-700 placeholder:text-slate-300"
                />
                <button 
                  type="submit"
                  disabled={isLoading}
                  className="p-3 bg-indigo-600 text-white rounded-xl shadow-lg shadow-indigo-100 hover:bg-indigo-700 active:scale-95 transition-all disabled:opacity-50"
                >
                  <Send className="w-5 h-5" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </main>

      {/* STPPA Detail Modal */}
      {showSTPPADetailModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setShowSTPPADetailModal(null)} />
          <div className="relative w-full max-w-2xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 flex flex-col max-h-[90vh]">
             <div className="bg-indigo-600 p-10 text-white relative">
               <button onClick={() => setShowSTPPADetailModal(null)} className="absolute top-6 right-6 p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"><X className="w-5 h-5" /></button>
               <span className="text-[10px] font-black bg-white/20 px-3 py-1 rounded-full uppercase tracking-widest mb-3 inline-block">Milestone STPPA</span>
               <h2 className="text-3xl font-black font-serif leading-none tracking-tight">{showSTPPADetailModal}</h2>
               <p className="text-indigo-100 font-bold text-sm mt-3 leading-relaxed opacity-90">{STPPA_AGE_DETAILS[showSTPPADetailModal].summary}</p>
             </div>
             
             <div className="flex-1 overflow-y-auto p-8 space-y-4 bg-slate-50 custom-scrollbar">
                <div className="grid grid-cols-1 gap-2">
                  {STPPA_AGE_DETAILS[showSTPPADetailModal].milestones.map((m: any, idx: number) => (
                    <div key={idx} className="bg-white p-5 rounded-2xl border border-slate-200 flex items-start gap-4 hover:border-indigo-100 transition-colors shadow-sm">
                       <div className="w-24 font-black text-[9px] text-indigo-500 uppercase border-r border-slate-100 pr-3 flex-shrink-0 mt-1">{m.aspect}</div>
                       <div className="text-xs text-slate-700 font-bold leading-relaxed">{m.detail}</div>
                    </div>
                  ))}
                </div>
             </div>
             
             <div className="p-8 bg-white border-t flex gap-4">
               <button onClick={() => setShowSTPPADetailModal(null)} className="flex-1 py-4 bg-slate-100 text-slate-600 font-black rounded-xl text-xs uppercase tracking-widest">Tutup</button>
               <button onClick={confirmAgeSelection} className="flex-1 py-4 bg-indigo-600 text-white font-black rounded-xl shadow-lg shadow-indigo-100 active:scale-95 transition-all text-xs uppercase tracking-widest">Gunakan Untuk Orkestrasi</button>
             </div>
          </div>
        </div>
      )}

      {/* Theme Insight Modal */}
      {showThemeModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setShowThemeModal(false)} />
          <div className="relative w-full max-w-4xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 max-h-[90vh] flex flex-col">
            <div className="joyful-gradient p-10 relative">
              <button onClick={() => setShowThemeModal(false)} className="absolute top-8 right-8 p-2 bg-white/60 rounded-full hover:bg-white transition-colors"><X className="w-5 h-5" /></button>
              <div className="flex items-center gap-2 mb-4">
                <span className="bg-indigo-600 text-white text-[9px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-md">Insight Pedagogis</span>
              </div>
              <h2 className="text-4xl font-black text-slate-800 font-serif">{prefs.theme}</h2>
              <div className="mt-4 flex flex-wrap gap-2">
                 <span className="bg-white/80 px-4 py-1.5 rounded-full text-[10px] font-bold text-slate-600 border border-white">Disiplin: {THEME_EXPLANATIONS[prefs.theme].discipline}</span>
                 <span className="bg-white/80 px-4 py-1.5 rounded-full text-[10px] font-bold text-slate-600 border border-white">Konsep: {THEME_EXPLANATIONS[prefs.theme].concept}</span>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-10 bg-slate-50/30 custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm relative group overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity"><BookOpen className="w-16 h-16" /></div>
                    <h3 className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-4">Pilar Prof. Somantri</h3>
                    <p className="text-slate-700 font-bold leading-relaxed italic text-sm border-l-4 border-emerald-200 pl-4">"{THEME_EXPLANATIONS[prefs.theme].somantriInsight}"</p>
                  </div>
                  
                  <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm relative group overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity"><Sparkles className="w-16 h-16" /></div>
                    <h3 className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-4">Relevansi OKKE</h3>
                    <p className="text-slate-600 font-bold leading-relaxed text-sm">{THEME_EXPLANATIONS[prefs.theme].okkeRelevance}</p>
                  </div>
                </div>
                
                <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
                  <h3 className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-6">Analisis Psikologis (Piaget & Vygotsky)</h3>
                  <div className="prose prose-sm font-bold text-slate-600 leading-loose whitespace-pre-line text-xs">
                    {THEME_EXPLANATIONS[prefs.theme].psychologicalContext}
                  </div>
                </div>
              </div>
            </div>
            <div className="p-8 bg-white border-t text-center">
              <button onClick={() => setShowThemeModal(false)} className="px-12 py-4 bg-slate-900 text-white font-black rounded-xl shadow-xl uppercase text-xs tracking-widest active:scale-95 transition-all">Selesai</button>
            </div>
          </div>
        </div>
      )}

      {/* Theory & OKKE Modals (simplified for brevity) */}
      {showOKKEModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setShowOKKEModal(false)} />
          <div className="relative w-full max-w-2xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="bg-slate-900 p-10 text-white">
              <h2 className="text-3xl font-black font-serif">Model OKKE</h2>
              <p className="text-slate-400 text-xs mt-2 uppercase tracking-widest">Orkestrasi Kurikulum & Kearifan Etnopedagogi</p>
            </div>
            <div className="flex-1 overflow-y-auto p-10 space-y-4 bg-slate-50">
               {MODEL_OKKE_INFO.pillars.map(p => (
                 <div key={p.id} className="bg-white p-6 rounded-2xl border border-slate-100 flex items-start gap-5">
                    <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center text-xl font-black flex-shrink-0">{p.id}</div>
                    <div>
                      <h4 className="font-black text-slate-800 text-sm mb-1 uppercase tracking-tight">{p.name}</h4>
                      <p className="text-slate-500 text-xs font-bold leading-relaxed">{p.desc}</p>
                    </div>
                 </div>
               ))}
            </div>
            <div className="p-8 bg-white border-t text-center">
               <button onClick={() => setShowOKKEModal(false)} className="px-10 py-4 bg-slate-900 text-white font-black rounded-xl text-xs uppercase tracking-widest">Tutup</button>
            </div>
          </div>
        </div>
      )}

      {showIPSModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setShowIPSModal(false)} />
          <div className="relative w-full max-w-xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden">
            <div className="bg-emerald-600 p-10 text-white">
              <h2 className="text-3xl font-black font-serif">Teori IPS PAUD</h2>
              <p className="text-emerald-100 text-xs mt-2 uppercase tracking-widest">Penyederhanaan ala Prof. Nu'man Somantri</p>
            </div>
            <div className="p-10 space-y-6 bg-slate-50">
               <div className="bg-white p-8 rounded-2xl border border-emerald-100 shadow-sm">
                  <p className="text-slate-700 font-bold italic leading-relaxed text-sm md:text-base">"{THEORY_IPS.definition}"</p>
               </div>
               <div className="bg-white p-8 rounded-2xl border border-slate-200">
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Relevansi di PAUD</h4>
                  <p className="text-slate-600 font-bold text-xs leading-loose">{THEORY_IPS.paudRelevance}</p>
               </div>
               <button onClick={() => setShowIPSModal(false)} className="w-full py-4 bg-slate-900 text-white font-black rounded-xl text-xs uppercase tracking-widest shadow-lg">Pahami Landasan</button>
            </div>
          </div>
        </div>
      )}

      {/* Simple Footer */}
      <footer className="p-8 text-center text-[10px] font-black text-slate-300 uppercase tracking-[0.4em] bg-slate-50">
        SocaPAUD &bull; Model OKKE &bull; &copy; 2025 Huriah Rachmah
      </footer>
    </div>
  );
};

export default App;