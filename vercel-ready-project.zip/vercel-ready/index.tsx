import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';

console.log("SocaPAUD: Starting application initialization...");

const rootElement = document.getElementById('root');

if (!rootElement) {
  console.error("SocaPAUD Fatal: Could not find root element with id 'root'");
} else {
  try {
    const root = createRoot(rootElement);
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
    console.log("SocaPAUD: React tree rendered successfully.");
  } catch (error) {
    console.error("SocaPAUD: Error during rendering:", error);
  }
}